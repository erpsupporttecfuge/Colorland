


{
    'name': "Customization of Barcode Report",
    'summary': """
  	""",
    'description': """
       barcode report""",
    'version': "13.0.1.0.0",
    'depends': ['stock'
    ],
    'data': [
'views/report_issue.xml'    ],
    'qweb': [

             ],

}
